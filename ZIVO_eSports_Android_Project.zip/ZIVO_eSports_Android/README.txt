ZIVO eSports Android package

App name: ZIVO eSports
Package: com.zivo.esports

This is an Android WebView project containing the current ZIVO eSports HTML app and logo.
Open this folder in Android Studio and build an APK (Build > Build APK(s)).
The app requires internet access because the tournament app uses online/Supabase features.
